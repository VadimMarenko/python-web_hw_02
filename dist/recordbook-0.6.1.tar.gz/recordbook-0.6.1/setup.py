# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['recordbook']

package_data = \
{'': ['*']}

install_requires = \
['rich>=13.5.2,<14.0.0']

entry_points = \
{'console_scripts': ['recordbook = recordbook.main:main']}

setup_kwargs = {
    'name': 'recordbook',
    'version': '0.6.1',
    'description': 'Command line bot-assistant',
    'long_description': '# python-web_hw_02\n\n',
    'author': 'VadimMarenko',
    'author_email': '130446385+VadimMarenko@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
